
const express = require('express');
const router = express.Router();
const Game = require('../models/Game');
const User = require('../models/User');
const jwt = require('jsonwebtoken');

function authMiddleware(req, res, next) {
    const token = req.headers.authorization;
    if (!token) return res.sendStatus(401);
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}

router.post('/bet', authMiddleware, async (req, res) => {
    const { amount, color } = req.body;
    const user = await User.findById(req.user.id);
    if (user.balance < amount) return res.status(400).json('Insufficient balance');
    user.balance -= amount;
    await user.save();
    const game = new Game({ userId: user._id, amount, color });
    await game.save();
    res.json('Bet placed');
});

router.get('/result', async (req, res) => {
    const lastGame = await Game.findOne().sort({ createdAt: -1 });
    res.json(lastGame);
});

module.exports = router;
